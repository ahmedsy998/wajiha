package app.wajiha.home;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.List;
import java.util.Set;

public class SettingsActivity extends Activity {
    private Prefs P;
    private Themes.T T;
    private Typeface tf;
    private float fs = 1f;
    private LinearLayout list;
    private Ui.SV sv;
    private String page = "main";
    private int focusIdx = 0;
    private final ArrayDeque<String> stack = new ArrayDeque<String>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        P = new Prefs(this);
        getWindow().setBackgroundDrawable(null);
        show("main");
    }

    @Override
    protected void onResume() {
        super.onResume();
        // قد تتغير حالة خدمة الوصول بعد العودة من إعدادات النظام
        if ("main".equals(page)) show(page);
    }

    @Override
    public void onBackPressed() {
        if (!stack.isEmpty()) {
            focusIdx = 0;
            show(stack.pop());
        } else {
            finish();
        }
    }

    private void go(String pg) {
        stack.push(page);
        focusIdx = 0;
        show(pg);
    }

    private String title(String pg) {
        if ("themes".equals(pg)) return "الثيم";
        if ("bg".equals(pg)) return "الخلفية";
        if ("fonts".equals(pg)) return "الخط";
        return "الإعدادات";
    }

    private void show(String pg) {
        page = pg;
        T = Themes.ALL[P.theme()];
        tf = Fonts.get(P.font());
        fs = Themes.FS[P.fscale()];

        FrameLayout root = Ui.background(this, P, T);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.u(170), Ui.u(26), Ui.u(170), 0);
        TextView head = Ui.text(this, title(pg), 28 * fs, T.text, tf);
        head.setPadding(Ui.u(8), 0, Ui.u(8), Ui.u(12));
        col.addView(head);

        sv = new Ui.SV(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setClipToPadding(false);
        sv.setPadding(0, Ui.u(10), 0, Ui.u(30));
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list, new FrameLayout.LayoutParams(-1, -2));
        col.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));

        fillPage(pg);
        setContentView(root);
        int n = list.getChildCount();
        if (n > 0) {
            View f = list.getChildAt(Math.max(0, Math.min(focusIdx, n - 1)));
            if (f != null) f.requestFocus();
        }
    }

    private View row(Drawable sw, String title, String value, Typeface titleFont, final Runnable r) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.HORIZONTAL);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(Ui.u(16), Ui.u(12), Ui.u(16), Ui.u(12));
        t.setFocusable(true);
        t.setClickable(true);
        t.setBackground(Ui.tileBg(T, Ui.u(12)));
        if (sw != null) {
            View s = new View(this);
            s.setBackground(sw);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.u(58), Ui.u(28));
            lp.setMarginEnd(Ui.u(14));
            t.addView(s, lp);
        }
        TextView a = Ui.text(this, title, 18 * fs, T.text, titleFont != null ? titleFont : tf);
        t.addView(a, new LinearLayout.LayoutParams(0, -2, 1f));
        if (value != null && !value.isEmpty()) {
            t.addView(Ui.text(this, value, 15 * fs, T.sub, tf));
        }
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.bottomMargin = Ui.u(7);
        t.setLayoutParams(rp);
        t.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean f) {
                if (f) Ui.reveal(sv, v);
            }
        });
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                focusIdx = list.indexOfChild(v);
                r.run();
            }
        });
        list.addView(t);
        return t;
    }

    private View row(String title, String value, Runnable r) {
        return row(null, title, value, null, r);
    }

    private Drawable swatch(int c1, int c2) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        g.setCornerRadius(Ui.u(8));
        g.setStroke(Math.max(1, Ui.u(1)), 0x66FFFFFF);
        return g;
    }

    private void note(String s) {
        TextView t = Ui.text(this, s, 13 * fs, T.sub, tf);
        t.setPadding(Ui.u(12), Ui.u(10), Ui.u(12), Ui.u(10));
        list.addView(t);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private static String mark(boolean on) {
        return on ? "●" : "";
    }

    // ---------------------------------------------------------------- الصفحات

    private void fillPage(String pg) {
        if ("themes".equals(pg)) {
            for (int i = 0; i < Themes.ALL.length; i++) {
                final int k = i;
                Themes.T t = Themes.ALL[i];
                row(swatch(t.c1, t.c2), t.name, mark(P.theme() == i), null, new Runnable() {
                    @Override
                    public void run() {
                        P.set("theme", k);
                        show(page);
                    }
                });
            }
            return;
        }
        if ("bg".equals(pg)) {
            row("حسب الثيم", mark(P.bg() == -1), new Runnable() {
                @Override
                public void run() {
                    P.set("bg", -1);
                    show(page);
                }
            });
            for (int i = 0; i < Themes.BG.length; i++) {
                final int k = i;
                row(swatch(Themes.BG[i][0], Themes.BG[i][1]), Themes.BG_NAMES[i], mark(P.bg() == i), null,
                    new Runnable() {
                        @Override
                        public void run() {
                            P.set("bg", k);
                            show(page);
                        }
                    });
            }
            row("صورة من الجهاز…", mark(P.bg() == 100), new Runnable() {
                @Override
                public void run() {
                    pickImage();
                }
            });
            note("الصورة المختارة تُصغَّر تلقائياً إلى 1280×720 لتبقى الواجهة خفيفة وسلسة.");
            return;
        }
        if ("fonts".equals(pg)) {
            List<String[]> fl = Fonts.list(this);
            for (final String[] f : fl) {
                row(null, f[1], mark(P.font().equals(f[0])), Fonts.get(f[0]), new Runnable() {
                    @Override
                    public void run() {
                        P.set("font", f[0]);
                        show(page);
                    }
                });
            }
            note("لإضافة خط خاص: ضع ملف ttf أو otf في المجلد Android/data/app.wajiha.home/files/fonts ثم افتح هذه الصفحة.");
            return;
        }

        row("الثيم", Themes.ALL[P.theme()].name, new Runnable() {
            @Override
            public void run() {
                go("themes");
            }
        });
        row("الخلفية", bgName(), new Runnable() {
            @Override
            public void run() {
                go("bg");
            }
        });
        row("الخط", fontName(), new Runnable() {
            @Override
            public void run() {
                go("fonts");
            }
        });
        row("حجم الخط", Themes.FS_NAMES[P.fscale()], new Runnable() {
            @Override
            public void run() {
                P.set("fscale", (P.fscale() + 1) % 3);
                show(page);
            }
        });
        row("تعتيم الخلفية", Themes.DIM_NAMES[P.dim()], new Runnable() {
            @Override
            public void run() {
                P.set("dim", (P.dim() + 1) % 4);
                show(page);
            }
        });
        row("نظام الساعة", P.h24() ? "24 ساعة" : "12 ساعة", new Runnable() {
            @Override
            public void run() {
                P.set("h24", !P.h24());
                show(page);
            }
        });
        row("الأرقام", P.ad() ? "عربية ٠١٢" : "إنجليزية 012", new Runnable() {
            @Override
            public void run() {
                P.set("ad", !P.ad());
                show(page);
            }
        });
        row("إظهار التاريخ", P.date() ? "نعم" : "لا", new Runnable() {
            @Override
            public void run() {
                P.set("date", !P.date());
                show(page);
            }
        });
        final int hid = P.hidden().size();
        row("إظهار التطبيقات المخفية", hid > 0 ? "(" + hid + ")" : "لا يوجد", new Runnable() {
            @Override
            public void run() {
                P.set("hid", new java.util.HashSet<String>());
                show(page);
            }
        });
        row("جعل «واجهتي» الشاشة الرئيسية", "", new Runnable() {
            @Override
            public void run() {
                setHome();
            }
        });
        row("تفعيل زر Home (خدمة الوصول)", accOn() ? "مفعّلة" : "غير مفعّلة", new Runnable() {
            @Override
            public void run() {
                enableAcc();
            }
        });
        row("إعدادات الشبكة", "", new Runnable() {
            @Override
            public void run() {
                open(Settings.ACTION_WIFI_SETTINGS);
            }
        });
        row("إعدادات النظام", "", new Runnable() {
            @Override
            public void run() {
                open(Settings.ACTION_SETTINGS);
            }
        });
        row("عن التطبيق", "الإصدار 1.0", new Runnable() {
            @Override
            public void run() {
                toast("واجهتي — مشغّل خفيف بالعربية بلا إعلانات ولا اتصال بالإنترنت.");
            }
        });
    }

    private String bgName() {
        int b = P.bg();
        if (b == 100) return "صورة مخصصة";
        if (b >= 0 && b < Themes.BG_NAMES.length) return Themes.BG_NAMES[b];
        return "حسب الثيم";
    }

    private String fontName() {
        String cur = P.font();
        for (String[] f : Fonts.list(this)) {
            if (f[0].equals(cur)) return f[1];
        }
        return "الافتراضي";
    }

    // ---------------------------------------------------------------- إجراءات النظام

    private void open(String action) {
        try {
            startActivity(new Intent(action));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (Exception e2) {
                toast("تعذّر فتح الإعدادات على هذا الجهاز");
            }
        }
    }

    private void setHome() {
        try {
            startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
            return;
        } catch (Exception ignored) {
        }
        try {
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            toast("اختر «واجهتي» ثم «دائماً» إن ظهرت نافذة الاختيار. وإن لم تظهر فعّل زر Home من الخيار التالي.");
        } catch (Exception e) {
            toast("تعذّر فتح اختيار الشاشة الرئيسية");
        }
    }

    private String serviceId() {
        return getPackageName() + "/" + HomeService.class.getName();
    }

    private boolean accOn() {
        try {
            String s = Settings.Secure.getString(getContentResolver(), "enabled_accessibility_services");
            return s != null && s.contains(serviceId());
        } catch (Exception e) {
            return false;
        }
    }

    private void enableAcc() {
        try {
            ContentResolver cr = getContentResolver();
            String cur = Settings.Secure.getString(cr, "enabled_accessibility_services");
            if (cur == null) cur = "";
            if (!cur.contains(serviceId())) {
                cur = cur.isEmpty() ? serviceId() : cur + ":" + serviceId();
                Settings.Secure.putString(cr, "enabled_accessibility_services", cur);
            }
            Settings.Secure.putInt(cr, "accessibility_enabled", 1);
            toast("تم تفعيل زر Home.");
            show(page);
        } catch (SecurityException e) {
            toast("فعّل خدمة «واجهتي» من إعدادات إمكانية الوصول ثم ارجع.");
            open(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        }
    }

    private void pickImage() {
        try {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            startActivityForResult(i, 1);
        } catch (Exception e) {
            toast("لا يوجد تطبيق لاختيار الصور على هذا الجهاز. ثبّت مدير ملفات ثم أعد المحاولة.");
        }
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent d) {
        super.onActivityResult(rq, rs, d);
        if (rq != 1 || rs != RESULT_OK || d == null || d.getData() == null) return;
        try {
            ContentResolver cr = getContentResolver();
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream in = cr.openInputStream(d.getData());
            BitmapFactory.decodeStream(in, null, o);
            in.close();
            int s = 1;
            while (o.outWidth / (s * 2) >= 1280 && o.outHeight / (s * 2) >= 720) s *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = s;
            in = cr.openInputStream(d.getData());
            Bitmap bm = BitmapFactory.decodeStream(in, null, o2);
            in.close();
            if (bm == null) throw new IllegalStateException();
            FileOutputStream fo = new FileOutputStream(new File(getFilesDir(), "bg.jpg"));
            bm.compress(Bitmap.CompressFormat.JPEG, 88, fo);
            fo.close();
            bm.recycle();
            P.set("bg", 100);
            show(page);
        } catch (Exception e) {
            toast("تعذّر استخدام هذه الصورة.");
        }
    }
}
