package app.wajiha.home;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Collator;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    static final int COLS = 6;
    static final String[] NAMES = {"يوتيوب", "نتفليكس", "برايم فيديو", "IPTV Pro"};
    static final String[] SLOT_AR = {"الأولى", "الثانية", "الثالثة", "الرابعة"};
    static final String[] HINT = {"youtube", "netflix", "prime", "iptv"};
    static final String[][] CAND = {
        {"com.google.android.youtube.tv", "com.google.android.youtube", "com.teamsmart.videomanager.tv"},
        {"com.netflix.ninja", "com.netflix.mediaclient"},
        {"com.amazon.amazonvideo.livingroom", "com.amazon.avod.thirdpartyclient"},
        {"ru.iptvremote.android.iptv.pro", "ru.iptvremote.android.iptv",
            "com.nst.iptvsmarterstvbox", "com.lazycatsoftware.iptv"}
    };

    static final class AppInfo {
        String pkg, label;
        ComponentName cn;
        Drawable icon;
    }

    private Prefs P;
    private Themes.T T;
    private Typeface tf;
    private float fs = 1f;

    private FrameLayout root;
    private LinearLayout main, content;
    private Ui.SV sv;
    private TextView clockV, dateV;
    private Ui.Icon netV, gearV;
    private View firstTile, lastFocus, overlay;
    private List<AppInfo> apps = new ArrayList<AppInfo>();
    private int shownVer = -1;
    private boolean registered;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final ExecutorService ex = Executors.newSingleThreadExecutor();
    private final SimpleDateFormat df = new SimpleDateFormat("EEEE d MMMM", new Locale("ar", "SY"));

    private final Runnable reload = new Runnable() {
        @Override
        public void run() {
            load();
        }
    };

    private final View.OnFocusChangeListener tileFocus = new View.OnFocusChangeListener() {
        @Override
        public void onFocusChange(View v, boolean f) {
            v.animate().scaleX(f ? 1.07f : 1f).scaleY(f ? 1.07f : 1f).setDuration(110).start();
            if (f) {
                lastFocus = v;
                Ui.reveal(sv, v);
            }
        }
    };

    private final View.OnFocusChangeListener iconFocus = new View.OnFocusChangeListener() {
        @Override
        public void onFocusChange(View v, boolean f) {
            v.animate().scaleX(f ? 1.12f : 1f).scaleY(f ? 1.12f : 1f).setDuration(110).start();
            if (f) lastFocus = v;
        }
    };

    private final BroadcastReceiver tickRx = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            if (ConnectivityManager.CONNECTIVITY_ACTION.equals(a)) net();
            else tick();
        }
    };

    private final BroadcastReceiver pkgRx = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            h.removeCallbacks(reload);
            h.postDelayed(reload, 700);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        P = new Prefs(this);
        getWindow().setBackgroundDrawable(null);
        build();
        load();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (P.ver() != shownVer) {
            build();
            fill();
        }
        tick();
        net();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (registered) return;
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_TIME_TICK);
        f.addAction(Intent.ACTION_TIME_CHANGED);
        f.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        f.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(tickRx, f);
        IntentFilter pf = new IntentFilter();
        pf.addAction(Intent.ACTION_PACKAGE_ADDED);
        pf.addAction(Intent.ACTION_PACKAGE_REMOVED);
        pf.addAction(Intent.ACTION_PACKAGE_REPLACED);
        pf.addDataScheme("package");
        registerReceiver(pkgRx, pf);
        registered = true;
        tick();
        net();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (registered) {
            try {
                unregisterReceiver(tickRx);
                unregisterReceiver(pkgRx);
            } catch (Exception ignored) {
            }
            registered = false;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        h.removeCallbacksAndMessages(null);
        ex.shutdownNow();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        // ضغط Home وأنت داخل الواجهة: ارجع للأعلى
        closeMenu();
        if (sv != null) sv.smoothScrollTo(0, 0);
        if (firstTile != null) firstTile.requestFocus();
    }

    @Override
    public void onBackPressed() {
        if (overlay != null) {
            closeMenu();
            return;
        }
        if (sv != null) sv.smoothScrollTo(0, 0);
        if (firstTile != null) firstTile.requestFocus();
    }

    // ---------------------------------------------------------------- بناء الواجهة

    private void build() {
        T = Themes.ALL[P.theme()];
        tf = Fonts.get(P.font());
        fs = Themes.FS[P.fscale()];
        overlay = null;
        firstTile = null;
        lastFocus = null;

        root = Ui.background(this, P, T);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(Ui.u(48), Ui.u(22), Ui.u(48), 0);
        root.addView(main, new FrameLayout.LayoutParams(-1, -1));

        // الشريط العلوي: الساعة ثم الشبكة ثم الضبط، كلها جهة اليمين
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout cb = new LinearLayout(this);
        cb.setOrientation(LinearLayout.VERTICAL);
        clockV = Ui.text(this, "", 40 * fs, T.text, tf);
        clockV.setTextDirection(View.TEXT_DIRECTION_LTR);
        dateV = Ui.text(this, "", 14 * fs, T.sub, tf);
        cb.addView(clockV);
        cb.addView(dateV);
        bar.addView(cb);

        netV = new Ui.Icon(this, 0, T);
        gearV = new Ui.Icon(this, 1, T);
        netV.setOnFocusChangeListener(iconFocus);
        gearV.setOnFocusChangeListener(iconFocus);
        netV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openWifi();
            }
        });
        gearV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(Ui.u(40), Ui.u(40));
        l1.setMarginStart(Ui.u(28));
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(Ui.u(40), Ui.u(40));
        l2.setMarginStart(Ui.u(12));
        bar.addView(netV, l1);
        bar.addView(gearV, l2);
        main.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        sv = new Ui.SV(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        sv.setClipToPadding(false);
        sv.setClipChildren(false);
        sv.setPadding(0, Ui.u(14), 0, Ui.u(40));
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setClipChildren(false);
        sv.addView(content, new FrameLayout.LayoutParams(-1, -2));
        main.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        setContentView(root);
        shownVer = P.ver();
    }

    private LinearLayout hrow() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setClipChildren(false);
        return r;
    }

    private LinearLayout.LayoutParams cell(int height) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, height, 1f);
        int m = Ui.u(6);
        p.setMargins(m, m, m, m);
        return p;
    }

    private void fill() {
        shownVer = P.ver();
        content.removeAllViews();
        firstTile = null;

        LinearLayout fr = hrow();
        for (int i = 0; i < 4; i++) {
            View t = featured(i, slotApp(i));
            if (firstTile == null) firstTile = t;
            fr.addView(t, cell(Ui.u(150)));
        }
        content.addView(fr);

        TextView lab = Ui.text(this, "كل التطبيقات", 16 * fs, T.sub, tf);
        lab.setPadding(Ui.u(8), Ui.u(18), Ui.u(8), Ui.u(6));
        content.addView(lab);

        Set<String> hid = P.hidden();
        LinearLayout row = null;
        int n = 0;
        for (AppInfo a : apps) {
            if (hid.contains(a.pkg)) continue;
            if (n % COLS == 0) {
                row = hrow();
                content.addView(row);
            }
            row.addView(appTile(a), cell(Ui.u(104)));
            n++;
        }
        while (row != null && n % COLS != 0) {
            row.addView(new View(this), cell(Ui.u(104)));
            n++;
        }
        if (overlay == null && firstTile != null) firstTile.requestFocus();
    }

    private AppInfo slotApp(int i) {
        String want = P.slot(i);
        if (!want.isEmpty()) {
            for (AppInfo a : apps) if (a.pkg.equals(want)) return a;
        }
        for (String c : CAND[i]) {
            for (AppInfo a : apps) if (a.pkg.equals(c)) return a;
        }
        for (AppInfo a : apps) {
            if (a.label.toLowerCase(Locale.ROOT).contains(HINT[i])) return a;
        }
        return null;
    }

    private LinearLayout tileBase() {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER);
        t.setFocusable(true);
        t.setClickable(true);
        t.setLongClickable(true);
        t.setBackground(Ui.tileBg(T, Ui.u(14)));
        t.setOnFocusChangeListener(tileFocus);
        return t;
    }

    private static Drawable copy(Drawable d) {
        Drawable.ConstantState cs = d.getConstantState();
        return cs != null ? cs.newDrawable().mutate() : d;
    }

    private View featured(final int i, final AppInfo a) {
        LinearLayout t = tileBase();
        if (a == null) {
            t.addView(Ui.text(this, NAMES[i], 20 * fs, T.text, tf));
            t.addView(Ui.text(this, "غير مثبّت", 13 * fs, T.sub, tf));
            t.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    toast("تطبيق " + NAMES[i] + " غير مثبّت على الجهاز");
                }
            });
            return t;
        }
        Drawable banner = null;
        try {
            banner = getPackageManager().getActivityBanner(a.cn);
        } catch (Exception ignored) {
        }
        if (banner != null) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageDrawable(banner);
            t.addView(iv, new LinearLayout.LayoutParams(-1, -1));
            t.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
            t.setClipToOutline(true);
        } else {
            ImageView iv = new ImageView(this);
            iv.setImageDrawable(copy(a.icon));
            t.addView(iv, new LinearLayout.LayoutParams(Ui.u(68), Ui.u(68)));
            TextView l = Ui.text(this, a.label, 17 * fs, T.text, tf);
            l.setSingleLine(true);
            l.setEllipsize(TextUtils.TruncateAt.END);
            l.setGravity(Gravity.CENTER);
            l.setPadding(Ui.u(8), Ui.u(8), Ui.u(8), 0);
            t.addView(l, new LinearLayout.LayoutParams(-1, -2));
        }
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launch(a);
            }
        });
        t.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                menu(a, i);
                return true;
            }
        });
        return t;
    }

    private View appTile(final AppInfo a) {
        LinearLayout t = tileBase();
        ImageView iv = new ImageView(this);
        iv.setImageDrawable(a.icon);
        t.addView(iv, new LinearLayout.LayoutParams(Ui.u(54), Ui.u(54)));
        TextView l = Ui.text(this, a.label, 13 * fs, T.text, tf);
        l.setSingleLine(true);
        l.setEllipsize(TextUtils.TruncateAt.END);
        l.setGravity(Gravity.CENTER);
        l.setPadding(Ui.u(6), Ui.u(6), Ui.u(6), 0);
        t.addView(l, new LinearLayout.LayoutParams(-1, -2));
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launch(a);
            }
        });
        t.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                menu(a, -1);
                return true;
            }
        });
        return t;
    }

    // ---------------------------------------------------------------- تحميل التطبيقات

    private void load() {
        if (ex.isShutdown()) return;
        ex.execute(new Runnable() {
            @Override
            public void run() {
                PackageManager pm = getPackageManager();
                LinkedHashMap<String, AppInfo> m = new LinkedHashMap<String, AppInfo>();
                String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
                for (String cat : cats) {
                    Intent i = new Intent(Intent.ACTION_MAIN).addCategory(cat);
                    for (ResolveInfo r : pm.queryIntentActivities(i, 0)) {
                        String p = r.activityInfo.packageName;
                        if (p.equals(getPackageName()) || m.containsKey(p)) continue;
                        AppInfo a = new AppInfo();
                        a.pkg = p;
                        a.cn = new ComponentName(p, r.activityInfo.name);
                        a.label = String.valueOf(r.loadLabel(pm));
                        a.icon = r.loadIcon(pm);
                        m.put(p, a);
                    }
                }
                final List<AppInfo> l = new ArrayList<AppInfo>(m.values());
                final Collator col = Collator.getInstance(new Locale("ar"));
                Collections.sort(l, new Comparator<AppInfo>() {
                    @Override
                    public int compare(AppInfo x, AppInfo y) {
                        return col.compare(x.label, y.label);
                    }
                });
                h.post(new Runnable() {
                    @Override
                    public void run() {
                        if (isDestroyed()) return;
                        apps = l;
                        fill();
                    }
                });
            }
        });
    }

    // ---------------------------------------------------------------- الساعة والشبكة

    private void tick() {
        if (clockV == null) return;
        Calendar c = Calendar.getInstance();
        int hr = c.get(Calendar.HOUR_OF_DAY), mn = c.get(Calendar.MINUTE);
        String s;
        if (P.h24()) {
            s = String.format(Locale.US, "%02d:%02d", hr, mn);
        } else {
            int h12 = hr % 12 == 0 ? 12 : hr % 12;
            s = String.format(Locale.US, "%d:%02d", h12, mn) + " " + (hr < 12 ? "ص" : "م");
        }
        clockV.setText(Ui.digits(s, P.ad()));
        if (P.date()) {
            dateV.setText(Ui.digits(df.format(c.getTime()), P.ad()));
            dateV.setVisibility(View.VISIBLE);
        } else {
            dateV.setVisibility(View.GONE);
        }
    }

    private void net() {
        if (netV == null) return;
        int t = 0;
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm.getActiveNetworkInfo();
            if (ni != null && ni.isConnected()) {
                t = ni.getType() == ConnectivityManager.TYPE_ETHERNET ? 2 : 1;
            }
        } catch (Exception ignored) {
        }
        netV.setState(t);
    }

    private void openWifi() {
        try {
            startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (Exception e2) {
                toast("تعذّر فتح الإعدادات");
            }
        }
    }

    // ---------------------------------------------------------------- تشغيل وقائمة التطبيق

    private void launch(AppInfo a) {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.setComponent(a.cn);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(i);
        } catch (Exception e) {
            toast("تعذّر فتح التطبيق");
        }
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private TextView item(String s, final Runnable r) {
        TextView t = Ui.text(this, s, 16 * fs, T.text, tf);
        t.setPadding(Ui.u(14), Ui.u(10), Ui.u(14), Ui.u(10));
        t.setFocusable(true);
        t.setClickable(true);
        t.setBackground(Ui.tileBg(T, Ui.u(10)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = Ui.u(5);
        t.setLayoutParams(p);
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r.run();
            }
        });
        return t;
    }

    private void menu(final AppInfo a, final int slot) {
        closeMenu();
        View cur = getCurrentFocus();
        if (cur != null) lastFocus = cur;

        LinearLayout m = new LinearLayout(this);
        m.setOrientation(LinearLayout.VERTICAL);
        m.setBackground(Ui.round(Ui.blend(T.c1, T.c2, 0.5f) | 0xFF000000, T.accent, Ui.u(2), Ui.u(18)));
        m.setPadding(Ui.u(16), Ui.u(14), Ui.u(16), Ui.u(10));

        TextView ti = Ui.text(this, a.label, 18 * fs, T.text, tf);
        ti.setPadding(Ui.u(8), 0, Ui.u(8), Ui.u(10));
        m.addView(ti);

        TextView first = null;
        for (int i = 0; i < 4; i++) {
            final int s = i;
            TextView it = item("تثبيت في الخانة " + SLOT_AR[i], new Runnable() {
                @Override
                public void run() {
                    P.set("slot" + s, a.pkg);
                    closeMenu();
                    fill();
                }
            });
            if (first == null) first = it;
            m.addView(it);
        }
        if (slot >= 0) {
            m.addView(item("إعادة هذه الخانة للوضع التلقائي", new Runnable() {
                @Override
                public void run() {
                    P.set("slot" + slot, "");
                    closeMenu();
                    fill();
                }
            }));
        }
        m.addView(item("إخفاء من القائمة", new Runnable() {
            @Override
            public void run() {
                Set<String> s = P.hidden();
                s.add(a.pkg);
                P.set("hid", s);
                closeMenu();
                fill();
            }
        }));
        m.addView(item("معلومات التطبيق", new Runnable() {
            @Override
            public void run() {
                closeMenu();
                try {
                    startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + a.pkg)));
                } catch (Exception e) {
                    toast("تعذّر فتح معلومات التطبيق");
                }
            }
        }));
        m.addView(item("إلغاء التثبيت", new Runnable() {
            @Override
            public void run() {
                closeMenu();
                try {
                    startActivity(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg)));
                } catch (Exception e) {
                    toast("تعذّر إلغاء التثبيت");
                }
            }
        }));
        m.addView(item("إغلاق", new Runnable() {
            @Override
            public void run() {
                closeMenu();
            }
        }));

        FrameLayout o = new FrameLayout(this);
        o.setBackgroundColor(0xB3000000);
        o.setClickable(true);
        o.addView(m, new FrameLayout.LayoutParams(Ui.u(400), -2, Gravity.CENTER));
        overlay = o;
        main.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        root.addView(o, new FrameLayout.LayoutParams(-1, -1));
        if (first != null) first.requestFocus();
    }

    private void closeMenu() {
        if (overlay == null) return;
        root.removeView(overlay);
        overlay = null;
        main.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
        if (lastFocus != null && lastFocus.getParent() != null) lastFocus.requestFocus();
        else if (firstTile != null) firstTile.requestFocus();
    }
}
