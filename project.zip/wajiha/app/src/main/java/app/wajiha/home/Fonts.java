package app.wajiha.home;

import android.content.Context;
import android.graphics.Typeface;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * الخطوط: لا نضمّن أي خط داخل التطبيق (للحفاظ على الحجم).
 * نستخدم خطوط النظام العربية الموجودة أصلاً، ونقرأ أي خط ttf/otf يضعه المستخدم
 * في مجلد Android/data/app.wajiha.home/files/fonts
 */
final class Fonts {
    private static final String[] DIRS = {
        "/system/fonts", "/system/product/fonts", "/product/fonts", "/vendor/fonts"
    };
    private static final String[] ARABIC_HINTS = {
        "arab", "naskh", "kufi", "cairo", "tajawal", "almarai", "amiri", "rubik", "changa"
    };

    private Fonts() {}

    static Typeface get(String key) {
        try {
            if (key == null || key.isEmpty()) return Typeface.DEFAULT;
            if (key.startsWith("s:")) return Typeface.create(key.substring(2), Typeface.NORMAL);
            if (key.startsWith("f:")) return Typeface.createFromFile(key.substring(2));
        } catch (Throwable ignored) {
        }
        return Typeface.DEFAULT;
    }

    /** كل عنصر: {المفتاح, الاسم المعروض} */
    static List<String[]> list(Context c) {
        List<String[]> l = new ArrayList<String[]>();
        l.add(new String[]{"", "الافتراضي"});
        l.add(new String[]{"s:sans-serif", "عادي"});
        l.add(new String[]{"s:sans-serif-medium", "متوسط"});
        l.add(new String[]{"s:sans-serif-light", "رفيع"});
        l.add(new String[]{"s:serif", "نسخ (Serif)"});
        l.add(new String[]{"s:casual", "عفوي"});
        l.add(new String[]{"s:cursive", "مخطوط"});
        l.add(new String[]{"s:monospace", "ثابت العرض"});

        for (String d : DIRS) scan(new File(d), l, true);
        try {
            File ext = c.getExternalFilesDir(null);
            if (ext != null) scan(new File(ext, "fonts"), l, false);
        } catch (Throwable ignored) {
        }
        scan(new File(c.getFilesDir(), "fonts"), l, false);
        return l;
    }

    private static void scan(File dir, List<String[]> out, boolean arabicOnly) {
        File[] fs = dir.listFiles();
        if (fs == null) return;
        java.util.Arrays.sort(fs);
        for (File f : fs) {
            String n = f.getName();
            String ln = n.toLowerCase(Locale.ROOT);
            if (!(ln.endsWith(".ttf") || ln.endsWith(".otf"))) continue;
            if (arabicOnly) {
                boolean ok = false;
                for (String h : ARABIC_HINTS) {
                    if (ln.contains(h)) { ok = true; break; }
                }
                if (!ok) continue;
            }
            String label = n.substring(0, n.length() - 4);
            out.add(new String[]{"f:" + f.getPath(), label});
        }
    }
}
