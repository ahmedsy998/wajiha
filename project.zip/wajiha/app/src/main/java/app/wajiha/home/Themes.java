package app.wajiha.home;

/** الثيمات والخلفيات الجاهزة. كلها ألوان برمجية بلا ملفات صور، لذلك حجمها صفر تقريباً. */
final class Themes {

    static final class T {
        final String name;
        final int c1, c2;      // تدرج الخلفية
        final int tile;        // لون البلاطة
        final int accent;      // لون التركيز
        final int text, sub;   // النص الرئيسي والثانوي
        final boolean glass;   // نمط زجاجي شفاف

        T(String name, int c1, int c2, int tile, int accent, int text, int sub, boolean glass) {
            this.name = name;
            this.c1 = c1;
            this.c2 = c2;
            this.tile = tile;
            this.accent = accent;
            this.text = text;
            this.sub = sub;
            this.glass = glass;
        }
    }

    static final int GLASS = 0x2EFFFFFF;

    static final T[] ALL = {
        new T("ليلي",   0xFF0A1020, 0xFF1D3357, 0xFF16213A, 0xFF4DA3FF, 0xFFFFFFFF, 0xFFA9B6CC, false),
        new T("زجاجي",  0xFF2B1B6B, 0xFF0E8A8F, GLASS,      0xFFFFFFFF, 0xFFFFFFFF, 0xCCFFFFFF, true),
        new T("أسود",   0xFF000000, 0xFF000000, 0xFF121212, 0xFFFFFFFF, 0xFFFFFFFF, 0xFF9A9A9A, false),
        new T("غروب",   0xFF2A0A3D, 0xFFE0562E, GLASS,      0xFFFFD27A, 0xFFFFFFFF, 0xCCFFFFFF, true),
        new T("غابة",   0xFF04201A, 0xFF1E6B4E, 0xFF0E3328, 0xFF5BE3A0, 0xFFFFFFFF, 0xFFA3C9B8, false),
        new T("محيط",   0xFF021A33, 0xFF0B7A9E, GLASS,      0xFF8FE8FF, 0xFFFFFFFF, 0xCCFFFFFF, true),
        new T("وردي",   0xFF3A0B2B, 0xFFA02D70, 0xFF4A1235, 0xFFFF8AD0, 0xFFFFFFFF, 0xFFE0B3D2, false),
        new T("ذهبي",   0xFF1A1405, 0xFF5A4410, 0xFF2A210A, 0xFFFFC94D, 0xFFFFFFFF, 0xFFD9C79A, false),
    };

    // خلفيات جاهزة مستقلة عن الثيم
    static final String[] BG_NAMES = {"ليل", "شفق", "ماء", "صحراء", "عشب", "رمادي"};
    static final int[][] BG = {
        {0xFF0A0F1F, 0xFF22345F},
        {0xFF3B1E6B, 0xFFE0566A},
        {0xFF0B3C5D, 0xFF3DB4B0},
        {0xFF3A2410, 0xFFD9A441},
        {0xFF0E3B2E, 0xFF8BC34A},
        {0xFF111418, 0xFF3A4350},
    };

    static final int[] DIM = {0x00, 0x33, 0x66, 0x99};
    static final String[] DIM_NAMES = {"بدون", "خفيف", "متوسط", "قوي"};
    static final float[] FS = {0.9f, 1f, 1.15f};
    static final String[] FS_NAMES = {"صغير", "عادي", "كبير"};

    private Themes() {}
}
