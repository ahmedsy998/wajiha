package app.wajiha.home;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;

/** أدوات الواجهة المشتركة. كل الأبعاد نسبة إلى ارتفاع الشاشة، فتبدو الواجهة نفسها على أي تلفاز. */
final class Ui {
    private static float h = 540f;

    private Ui() {}

    static void init(Context c) {
        DisplayMetrics m = c.getResources().getDisplayMetrics();
        h = Math.min(m.widthPixels, m.heightPixels);
    }

    /** وحدة مرجعية: الشاشة بارتفاع 540 وحدة */
    static int u(float v) {
        return Math.round(v * h / 540f);
    }

    static int blend(int a, int b, float t) {
        return Color.argb(
            Math.round(Color.alpha(a) * (1 - t) + Color.alpha(b) * t),
            Math.round(Color.red(a) * (1 - t) + Color.red(b) * t),
            Math.round(Color.green(a) * (1 - t) + Color.green(b) * t),
            Math.round(Color.blue(a) * (1 - t) + Color.blue(b) * t));
    }

    static TextView text(Context c, String s, float size, int color, Typeface tf) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(size));
        if (tf != null) t.setTypeface(tf);
        return t;
    }

    static GradientDrawable round(int fill, int stroke, int strokePx, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radius);
        if (strokePx > 0) g.setStroke(strokePx, stroke);
        return g;
    }

    /** خلفية البلاطة: عادية، وعند التركيز تظهر حلقة بلون التمييز */
    static StateListDrawable tileBg(Themes.T t, float radius) {
        StateListDrawable s = new StateListDrawable();
        int focusFill = t.glass ? 0x59FFFFFF : blend(t.tile, t.accent, 0.28f);
        s.addState(new int[]{android.R.attr.state_focused}, round(focusFill, t.accent, Math.max(2, u(3)), radius));
        s.addState(new int[0], round(t.tile, 0x33FFFFFF, t.glass ? Math.max(1, u(1)) : 0, radius));
        return s;
    }

    /** أرقام عربية أو إنجليزية حسب الإعداد */
    static String digits(String s, boolean arabic) {
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch >= '٠' && ch <= '٩') ch = (char) ('0' + (ch - '٠'));
            else if (ch >= '۰' && ch <= '۹') ch = (char) ('0' + (ch - '۰'));
            if (arabic && ch >= '0' && ch <= '9') ch = (char) ('٠' + (ch - '0'));
            b.append(ch);
        }
        return b.toString();
    }

    /** الخلفية: تدرج لوني أو صورة المستخدم، مع طبقة تعتيم اختيارية */
    static FrameLayout background(Context c, Prefs p, Themes.T t) {
        FrameLayout r = new FrameLayout(c);
        ImageView iv = new ImageView(c);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        boolean image = false;
        if (p.bg() == 100) {
            File f = new File(c.getFilesDir(), "bg.jpg");
            if (f.exists()) {
                Bitmap b = BitmapFactory.decodeFile(f.getPath());
                if (b != null) {
                    iv.setImageBitmap(b);
                    image = true;
                }
            }
        }
        if (!image) {
            int a = t.c1, b2 = t.c2;
            int bi = p.bg();
            if (bi >= 0 && bi < Themes.BG.length) {
                a = Themes.BG[bi][0];
                b2 = Themes.BG[bi][1];
            }
            iv.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{a, b2}));
        }
        r.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        int alpha = Themes.DIM[p.dim()];
        if (alpha > 0) {
            View d = new View(c);
            d.setBackgroundColor(alpha << 24);
            r.addView(d, new FrameLayout.LayoutParams(-1, -1));
        }
        return r;
    }

    /** ScrollView بلا قفزات: نعطّل تمرير النظام الفوري ونستعمل التمرير الناعم */
    static final class SV extends ScrollView {
        SV(Context c) {
            super(c);
        }

        @Override
        protected int computeScrollDeltaToGetChildRectOnScreen(Rect rect) {
            return 0;
        }
    }

    /** يمرّر العنصر المركّز إلى داخل الشاشة بحركة ناعمة */
    static void reveal(SV sv, View v) {
        if (sv == null || v.getParent() == null) return;
        Rect r = new Rect();
        v.getDrawingRect(r);
        try {
            sv.offsetDescendantRectToMyCoords(v, r);
        } catch (IllegalArgumentException e) {
            return;
        }
        int m = u(16);
        int top = sv.getScrollY();
        int bottom = top + sv.getHeight();
        int target = top;
        if (r.top < top + m) target = r.top - m;
        else if (r.bottom > bottom - m) target = r.bottom - sv.getHeight() + m;
        if (target != top) sv.smoothScrollTo(0, Math.max(0, target));
    }

    /** أيقونات الشريط العلوي، مرسومة بالكود (بلا صور): 0 شبكة، 1 ضبط */
    static final class Icon extends View {
        private final int kind;
        private int state;
        private final int color;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Icon(Context c, int kind, Themes.T t) {
            super(c);
            this.kind = kind;
            this.color = t.text;
            setFocusable(true);
            setClickable(true);
            setBackground(tileBg(t, u(10)));
        }

        /** 0 غير متصل، 1 واي فاي، 2 إيثرنت */
        void setState(int s) {
            if (s != state) {
                state = s;
                invalidate();
            }
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), hh = getHeight();
            float s = Math.min(w, hh) * 0.62f;
            p.setColor(color);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(s * 0.1f);
            c.save();
            c.translate((w - s) / 2f, (hh - s) / 2f);
            if (kind == 1) gear(c, s);
            else if (state == 2) ethernet(c, s);
            else wifi(c, s, state == 1);
            c.restore();
        }

        private void wifi(Canvas c, float s, boolean on) {
            float cx = s / 2f, cy = s * 0.86f;
            p.setAlpha(on ? 255 : 110);
            for (int i = 1; i <= 3; i++) {
                float r = s * 0.23f * i;
                c.drawArc(new RectF(cx - r, cy - r, cx + r, cy + r), -135f, 90f, false, p);
            }
            p.setStyle(Paint.Style.FILL);
            c.drawCircle(cx, cy, s * 0.07f, p);
            if (!on) {
                p.setAlpha(255);
                p.setStyle(Paint.Style.STROKE);
                c.drawLine(s * 0.1f, s * 0.08f, s * 0.9f, s * 0.95f, p);
            }
            p.setAlpha(255);
        }

        private void ethernet(Canvas c, float s) {
            c.drawRoundRect(new RectF(s * 0.12f, s * 0.14f, s * 0.88f, s * 0.62f), s * 0.08f, s * 0.08f, p);
            for (int i = 0; i < 3; i++) {
                float x = s * (0.3f + 0.2f * i);
                c.drawLine(x, s * 0.14f, x, s * 0.36f, p);
            }
            c.drawLine(s * 0.5f, s * 0.62f, s * 0.5f, s * 0.84f, p);
            c.drawLine(s * 0.28f, s * 0.84f, s * 0.72f, s * 0.84f, p);
        }

        private void gear(Canvas c, float s) {
            c.save();
            c.translate(s / 2f, s / 2f);
            p.setStrokeWidth(s * 0.12f);
            c.drawCircle(0, 0, s * 0.24f, p);
            for (int i = 0; i < 8; i++) {
                c.drawLine(0, -s * 0.34f, 0, -s * 0.46f, p);
                c.rotate(45f);
            }
            c.restore();
        }
    }
}
