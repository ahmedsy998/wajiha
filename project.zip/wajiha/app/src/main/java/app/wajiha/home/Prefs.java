package app.wajiha.home;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

/** إعدادات المستخدم. كل تعديل يرفع رقم النسخة ليعيد الواجهة بناء نفسها. */
final class Prefs {
    private final SharedPreferences sp;

    Prefs(Context c) {
        sp = c.getSharedPreferences("p", Context.MODE_PRIVATE);
    }

    int theme() {
        int t = sp.getInt("theme", 0);
        return t < 0 || t >= Themes.ALL.length ? 0 : t;
    }

    int bg() { return sp.getInt("bg", -1); }          // -1 حسب الثيم، 0..5 جاهزة، 100 صورة
    String font() { return sp.getString("font", ""); }
    int fscale() { return clamp(sp.getInt("fscale", 1), 2); }
    int dim() { return clamp(sp.getInt("dim", 1), 3); }
    boolean h24() { return sp.getBoolean("h24", false); }
    boolean ad() { return sp.getBoolean("ad", true); }
    boolean date() { return sp.getBoolean("date", true); }
    String slot(int i) { return sp.getString("slot" + i, ""); }
    int ver() { return sp.getInt("ver", 0); }

    Set<String> hidden() {
        Set<String> s = sp.getStringSet("hid", null);
        return s == null ? new HashSet<String>() : new HashSet<String>(s);
    }

    void set(String k, Object v) {
        SharedPreferences.Editor e = sp.edit();
        if (v instanceof Integer) e.putInt(k, (Integer) v);
        else if (v instanceof Boolean) e.putBoolean(k, (Boolean) v);
        else if (v instanceof String) e.putString(k, (String) v);
        else if (v instanceof Set) {
            Set<String> s = new HashSet<String>();
            for (Object o : (Set<?>) v) s.add(String.valueOf(o));
            e.putStringSet(k, s);
        }
        e.putInt("ver", ver() + 1).apply();
    }

    private static int clamp(int v, int max) { return v < 0 ? 0 : Math.min(v, max); }
}
