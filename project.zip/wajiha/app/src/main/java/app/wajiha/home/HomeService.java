package app.wajiha.home;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;

/**
 * خدمة اختيارية: عندما تفتح واجهة النظام الأصلية (بعد زر Home) تعيدك إلى واجهتي.
 * تُستعمل حين يمنع التلفاز تغيير الشاشة الرئيسية الافتراضية (مثل Google TV).
 * لا تقرأ أي محتوى من الشاشة.
 */
public class HomeService extends AccessibilityService {
    private long last;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null || e.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        long now = System.currentTimeMillis();
        if (now - last < 700) return;
        last = now;
        try {
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(i);
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onInterrupt() {
    }
}
