#!/usr/bin/env bash
# بناء محلي على حاسوب فيه JDK 17 و Android SDK (أو Android Studio).
set -e
mkdir -p ~/.android
[ -f ~/.android/debug.keystore ] || keytool -genkeypair -keystore ~/.android/debug.keystore \
  -storepass android -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 \
  -validity 10000 -dname "CN=Android Debug,O=Android,C=US"
cd "$(dirname "$0")"
./gradlew assembleRelease
echo "الملف الجاهز: app/build/outputs/apk/release/app-release.apk"
